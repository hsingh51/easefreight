<?php
session_start();
if(isset($_POST['send_email'])) {
    if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone']) && !empty($_POST['require'])) {

          $name=$_POST['name'];
          $email=$_POST['email'];
          $phone=$_POST['phone'];
          $require=$_POST['require'];
           
        function sendElasticEmail($to, $subject, $body_text, $body_html, $from, $fromName) {
            $res = "";

            $data = "username=".urlencode("01s@01s.in");
            $data .= "&api_key=".urlencode("9596a3f6-84a8-4d49-84f6-e80d80e872be");
            $data .= "&from=".urlencode($from);
            $data .= "&from_name=".urlencode($fromName);
            $data .= "&to=".urlencode($to);
            $data .= "&subject=".urlencode($subject);
            $body_html="
            <h1>Offshore IT Staffing.</h1>
            <p>User Information</p>
            <table>
                <tr>
                    <td>Name - </td>
                    <td>".$_POST['name']."</td>
                </tr>
                 <tr>
                    <td>Email Address - </td>
                    <td>".$_POST['email']."</td>
                </tr>
                 <tr>
                    <td>Contact Number - </td>
                    <td>".$_POST['phone']."</td>
                </tr>
                 <tr>
                    <td>Requirement - </td>
                    <td>".$_POST['require']."</td>
                </tr>
            </table>
            ";

            if($body_html)
              $data .= "&body_html=".urlencode($body_html);
            if($body_text)
              $data .= "&body_text=".urlencode($body_text);

            $header = "POST /mailer/send HTTP/1.0\r\n";
            $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
            $header .= "Content-Length: " . strlen($data) . "\r\n\r\n";
            $fp = fsockopen('ssl://api.elasticemail.com', 443, $errno, $errstr, 30);

            if(!$fp)
              return "ERROR. Could not open connection";
            else {
              fputs ($fp, $header.$data);
              while (!feof($fp)) {
                $res .= fread ($fp, 1024);
              }
              fclose($fp);
            }
            return $res;                  
        }
       sendElasticEmail("hello@01synergy.com", "Offshore IT Staffing.", "My Text", $body_html, "hello@01synergy.com", "Offshore IT Staffing");
        $_SESSION['message']="Your Request is submitted successfully";

    }
    else{
        $_SESSION['message']="Both Fields are Required";
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Offshore IT Staffing - Hire iOS, Android, PHP, .NET Programmers today! </title>
    <style>
        form label {
            color: #FFF !important;
        }
        .ny_align, .toro_align, .ldh_align {float: right !important;}
    </style>
    <meta name ="description" content="Extend your IT team with one dedicated programmer or a entire team. We provide dedicated, cost effective software programmers since 1997">
          <link rel="author" href="https://plus.google.com/+PreetChandhoke"/>

    
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/animate.css" />
    <!--link rel="stylesheet" href="css/example.css"-->
    <link type="text/css" rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/vendor/modernizr-2.7.1.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $("#priceclick").click(function() {
                $('html,body').animate({
                        scrollTop: $("#pricing").offset().top
                    },
                    'slow');

            });
            $("#home").click(function() {
                $('html,body').animate({
                        scrollTop: $("#navigation").offset().top
                    },
                    'slow');

            });
            $("#whythis").click(function() {
                $('html,body').animate({
                        scrollTop: $("#whyois").offset().top
                    },
                    'slow');

            });
            $("#work").click(function() {
                $('html,body').animate({
                        scrollTop: $("#howitworks").offset().top
                    },
                    'slow');

            });


        });

    </script>
</head>

<body>
    <!--top div-->
    <div class="topbar"></div>

    <!--nav-->
    <div id="navigation" class="navigation">
        <div class="container">
            <nav class="navbar">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"><img src="images/logo.png" class="logo" alt=""></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">

                        <ul class="nav navbar-nav navbar-right">
                    
                            <li><a id="priceclick" href="javascript:void(0);">OUR DEVELOPERS</a></li>
                            <li><a id="whythis" href="javascript:void(0);">WHY OIS</a></li>
                            <li><a id="work" href="javascript:void(0);">HOW IT WORKS</a></li>
                            <li><a data-toggle="modal" data-target="#myModal" href="#">FAQ'S</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!--    nav ends-->

    <!--   slider starts-->
    <div class="container-slide">
        <div id="slides">
            <img src="images/means.png">
            <img src="images/android.png">
            <img src="images/ios.png">
            <img src="images/php.png">
            <img src="images/dotnet.png">
        </div>
        <button class="prev" onClick="slideback()" type="button"><i class="fa fa-chevron-left"></i>
        </button>
        <button class="next" onClick="slidenext()" type="button"><i class="fa fa-chevron-right"></i></button>
        <script>
            function slideback() {
                $('.slidesjs-previous').click();
            }

            function slidenext() {
                $('.slidesjs-next').click();
            }

        </script>
    </div>
    <!--    slider ends-->
    <!-- SlidesJS Required: Link to jquery.slides.js -->
    <script src="js/jquery.slides.js"></script>
    <!-- End SlidesJS Required -->
    <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <!-- SlidesJS Required: Initialize SlidesJS with a jQuery doc ready -->
    <script>

$(document).ready(function() {
  
    // Setup form validation on the #register-form element
    $("#register-form").validate({
    
        // Specify the validation rules
        rules: {
            name: "required",
            
            email: {
                required: true,
                email: true
            },
            phone: "required",
            require: "required"
        },
        
        // Specify the validation error messages
        messages: {
            name: "Please enter your Name",
            email: {
                required: "Please enter an email address",
                email: "Please enter a valid email address"

            },
            phone: "Please enter your Phone Number",
            require: "Please Write your Requirements"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

 
            $('#slides').slidesjs({
                width: 940,
                height: 528,
                play: {
                    active: true,
                    auto: true,
                    interval: 4000,
                    swap: true
                }
            });
        });

    </script>
    <!-- End SlidesJS Required -->

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content colorgrey OpenSans-Regular">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title colorgreen OpenSans-Semibold">Here are some common questions we recieve about remote staffing and our services.</h4>
                </div>
                <div class="modal-body">
                    <p class="colorgreen"><b>How do I get the right professionals for the assignment?</b></p>
                    <div>Our client service executives work closely with you to gain a thorough understanding of the skills your project equires. Staff selection begins with a review of the technical skills and experience levels required by your project, but it doesn't end there. We also look at your organization's development style, and the domain of your project to help ensure a successful staff placement. This information, along with our experience, allows us to pick the right staff for your assignment.</div>
                    <br/>
                    <div>We have found that spending the time to get the full picture before making a staffing decision leads to better selections and a more satisfying experience for both clients and staff members - but the final choice lies with you. If you decide that your staff placement just isn't working out, we'll revise your staff until you're satisfied.</div>
                    <br/>
                    <p class="colorgreen"><b>Who supervises my remote staff?</b></p>
                    <div>Your outsourced professionals function as remotely-based employees who report to you for technical direction. They receive day-to-day supervision and workload management by you. Each client, however, is assigned a client services executive who is there to support you for any issues that may arise.</div>
                    <br/>
                    <p class="colorgreen"><b>How do I communicate with my remote professionals?</b></p>
                    <div>While your professionals are remotely located in our facilities, they are readily accessible by you. A key step in initiating your service is designing a communication plan the suits your preferences. Typically our clients use one or more of the following methods for communication:</div>
                    <ul>
                        <li>Email</li>
                        <li>Instant Messaging (GTalk, Skype, Yahoo Messenger)
                
                        <li>Standard telephone </li>
                    </ul>
                    <br/>
                    <div>As part of your communication plan, we will help you establish your preferences and priorities for communication methods and create guidelines for whom to contact in your organization for particular issues.</div>
                    <br/>
                    <p class="colorgreen"><b>How quickly can I get started?</b></p>
                    <div>We can get the process started today. The length of time to get your professionals assigned and working for you largely depends upon the particular skills and level of experience you are seeking. Contact US NOW! and we can quickly provide you an estimate tailored to your requirements.</div>
                    <br/>
                    <p class="colorgreen"><b>Is there a minimum staff size or duration of engagement?</b></p>
                    <div>There is no minimum required number of professionals for an engagement. Whether you need just one or ten resources, we will diligently work to get you the right staff for your needs.</div>
                    <br/>
                    <div>Our professionals are outsourced on a month-to-month basis so there is no long-term commitment you need to make. One month is the minimum engagement period for individual staff members. Three months is the minimum engagement period for a managed team.</div>
                    <br/>
                    <p class="colorgreen"><b>What about news reports that say I'm hurting the economy by moving jobs overseas?</b></p>
                    <div>This is certainly not the case. The choice to use offshore resource is no different than any other business decision that lowers the cost of production. Whether its buying from the supplier with the best price or finding a better way to get work done, every business decision that improves the efficiency of production benefits the economy as a whole, though it may not benefit a specific individual.
                    </div>
                    <br/>
                    <div>We all know the sting of being on the wrong side of such business decisions, whether its losing a bid to a competitor or losing a job to downsizing. But as unpleasant as it might be, there is no escaping the laws of economics - improvements in the efficiency of production conveys a benefit to the economy as a whole through less expensive goods and services.</div>
                    <br/>
                  
                    </ul>
                </div>
                <div class="modal-footer">

                </div>
            </div>

        </div>
    </div>
    <!--   Our Features Container-->
    <section id="pricing" class="pt99">
        <div class="feature-container bcg" data-0="background-color:rgb(1,27,59);" data-top="background-color:(0,0,0);" data-anchor-target="#pricing">
            <div class="container">
                <div class="main-heading" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">our <span>Developers</span></div>
                <div class="sub-head">Offshore IT Staffing has Developers who are very Passionate about Programming. </div>
                <div class="mt70" data-center="opacity: 1" data--200-bottom="opacity: 1" data-206-top="opacity: 1" data-106-top="opacity: 1"  data-anchor-target=".mt70">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="service-item">
                                <div id="php" class="text-center height300 ptb20">
                                    <img src="images/mean.png" width="150px" alt="">
                                    <div class="img-heading">MEAN Stack</div>
                                </div>
                                <div id="phphover" class="hoverdiv">
                                    <div class="hov-txt">MEAN Stack Developers</div>
                                    <div class="hovers">Angular, Node.js, MongoDB, Express.</div>
                                    <div class="hovers-bold">Hire now for USD 1899 a month</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="service-item animated bounce">
                                <div class="text-center height300  ptb20">
                                    <!-- <img src="images/dotnetdev.png" width="150px" alt=""> -->
                                     <img src="images/phpdev.png" width="150px" alt="">
                                    <div class="img-heading">PHP Developers</div>
                                </div>
                                <!-- <div id="nethover" class="hoverdiv">
                                    <div class="hov-txt">.NET Developers</div>
                                    <div class="hovers">VB.NET, Visual Studio, C#, Silverlight, Azure, MS Dynamics CRM, AX, NAV</div>
                                    <div class="hovers-bold">Hire now for USD 1199 a month</div>
                                </div> -->

                                <div id="phphover" class="hoverdiv">
                                    <div class="hov-txt">PHP Developers</div>
                                    <div class="hovers">Wordpress, Magento, Joomla, xCart, Drupal, Symfony, Zend, Cake PHP </div>
                                    <div class="hovers-bold">Hire now for USD 1499 a month</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="service-item">
                                <div class="text-center height300  ptb20">
                                    <!-- <img src="images/iosdev.png" width="150px" alt=""> -->
                                    <img src="images/dotnetdev.png" width="150px" alt="">
                                   <!--  <div class="img-heading">iOS, TvOS, WatchOS Developers</div> -->
                                    <div class="img-heading">.NET Developers</div>
                                </div>
                               <!--  <div id="ioshover" class="hoverdiv">
                                    <div class="hov-txt">iOS, TvOS, WatchOS Developers</div>
                                    <div class="hovers"></div>
                                    <div class="hovers-bold">Hire now for USD 1199 a month</div>
                                </div> -->
                                <div id="nethover" class="hoverdiv">
                                    <div class="hov-txt">.NET Developers</div>
                                    <div class="hovers">VB.NET, Xamarin, Visual Studio, C#, Silverlight, Azure, MS Dynamics CRM, AX, NAV</div>
                                    <div class="hovers-bold">Hire now for USD 1499 a month</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="service-item">
                                <div class="text-center height300  ptb20">
                                    <img src="images/and_1.png" width="150px" alt="">
                                    <div class="img-heading">Mobile Developers</div>
                                </div>
                                <div id="androidhover" class="hoverdiv">
                                    <div class="hov-txt">Mobile Developers</div>
                                    <div class="hovers">Android, iOS, Phonegap, Ionic</div>
                                    <div class="hovers-bold">Hire now for USD 1499 a month</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    our features container ends-->
    <!--Why Hire container-->
    <div id="whyois" class="pt99 rivision1">
        <div class="why-container">
            <div class="container">
                <div class="main-heading colorwhite" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">why hire remote <span>programmers</span> from ois</div>
                <div class="mtb40-0">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/1.png" alt="">
                                <div class="icon-txt">Hire full time, dedicated staff members who work only for you</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/2.png" alt="">
                                <div class="icon-txt">Staff long term projects, or relief engagement as short as 1 month </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/3.png" alt="">
                                <div class="icon-txt">Use only one person or deploy an entire team</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/4.png" alt="">
                                <div class="icon-txt">Skilled, Experienced Programmers available to start today!</div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/5.png" alt="">
                                <div class="icon-txt">Professionals work 8 hour shifts, 160 hours per month</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/6.png" alt="">
                                <div class="icon-txt">No more ‘hit or miss’ freelancers</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/7.png" alt="">
                                <div class="icon-txt">No long term contracts or commitments</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="text-center">
                                <img data-anijs="if: scroll, on: window, do: fadeIn animated, before: scrollReveal;" src="images/8.png" alt="">
                                <div class="icon-txt">Get started in 48-72 hours</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    points container-->
    <div id="howitworks" class="pt99 rivision2">
        <div class="points-container">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <div class="text-center">
                            <img src="images/1a.png" alt="">
                            <div class="point-heading" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">How it Works?</div>

                            <ul class="text-left pointing">
                                <li>IT professionals are full time employee of OIS</li>
                                <li>OIS provide them with a relevent software & equipment</li>
                                <li>Your resource sends in daily update and commits code to your repository </li>
                                <li>You can speak directly with your resource on phone, email or instant messanger</li>
                            </ul>

                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <div class="text-center">
                            <img src="images/2a.png" alt="">
                            <div class="point-heading" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">What you get?</div>
                            <ul class="text-left pointing">
                                <li>Experienced IT professionals</li>
                                <li>Full time dedicated Programmer</li>
                                <li>Dedicately working for you on your project</li>
                                <li>For 8 hours shifts,5 day per week for 160 hours a month</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <div class="text-center">
                            <img src="images/3a.png" alt="">
                            <div class="point-heading" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">OIS Advantage</div>
                            <ul class="text-left pointing">
                                <li>A solution company with 17 years of Industry experience</li>
                                <li>Our solution will enable you to flex your staffing levels as your needs change</li>
                                <li>No payroll benifits, No W2s, No 1099s to work about</li>
                                <li>No equipment, software, office space or overhead costs</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <div class="text-center">
                            <img src="images/4a.png" alt="">
                            <div class="point-heading" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">How to get started?</div>
                            <div>
                                <form method="post" id="register-form">
                                    <input class="input-contact" placeholder="Name" name="name" type="text">
                                    <input class="input-contact" placeholder="Email" name="email" type="email">
                                    <input class="input-contact" placeholder="Requirement" name="require" type="text">
                                    <input class="input-contact" placeholder="Phone Number" name="phone" type="text">
                                    <input data-anijs="if: scroll, on: window, do: bounceIn animated, before: scrollReveal;" class="send-btn" type="submit" name="send_email" value="Submit">
                                </form>
                                <p style="color: #FFF;">
                                    <?php
                                        if(isset($_SESSION['message']) && !empty($_SESSION['message'])) {
                                            echo $_SESSION['message'];
                                            unset($_SESSION['message']);
                                        }
                                    ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--points container end-->

    <!--   contact container-->
    <div class="contact-container">
        <div class="container">
            <div class="main-heading colorwhite" data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;">Connect with us</div>
            <div>
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <div class="text-left">
                            <div class="con-head">Follow Us</div>
                            <div>
                                <ul class="list-unstyled inline">
                                    <li>
                                        <a data-anijs="if: scroll, on: window, do: fadeInLeft animated, before: scrollReveal;" href="https://www.facebook.com/01Synergy/"><i class="fa fa-facebook"></i>
</a>
                                    </li>
                                    <li>
                                        <a data-anijs="if: scroll, on: window, do: fadeInUp animated, before: scrollReveal;" href="https://twitter.com/01synergy_"><i class="fa fa-twitter"></i>
</a>
                                    </li>
                                    <li>
                                        <a data-anijs="if: scroll, on: window, do: fadeInDown animated, before: scrollReveal;" href="https://www.linkedin.com/company/01-synergy"><i class="fa fa-linkedin"></i>
</a>
                                    </li>
                                    <li>
                                        <a data-anijs="if: scroll, on: window, do: fadeInRight animated, before: scrollReveal;" href="https://plus.google.com/107757975286535258921/about"><i class="fa fa-google-plus"></i>
</a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-9">
                        <div class="con-head">Office Locations</div>
                        <!-- <div class="col-md-3 col-sm-3">
                            <div class="flagdiv">
                                <div class="flag"><img src="images/bugata.png" width="35" alt=""> Bogota</div>
                                <div class="flag">+57 300.207.0255</div>
                            </div>
                        </div> -->
                        <div class="col-md-3 col-sm-3 ny_align">
                            <div class="flagdiv">
                                <div class="flag"><img src="images/1280px-Flag_of_the_United_States.svg.png" width="35" alt=""> New York</div>
                                <div class="flag">+1 347.871.2544</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 toro_align">
                            <div class="flagdiv">
                                <div class="flag"><img src="images/Flag_of_Canada.png" width="35" alt=""> Toronto</div>
                                <div class="flag">+1 647.292.8845</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 ldh_align">
                            <div class="flagdiv">
                                <div class="flag"><img src="images/india.png" width="35" alt=""> Ludhiana</div>
                                <div class="flag">+91 981.591.8807</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    footer-->
    <div class="foot">MADE WITH LOVE <img src="images/heart.png" alt=""> @ Offshore IT Staffing </div>
</body>
<script src="js/anijs/anijs.js"></script>
<script src="js/anijs/helpers/scrollreveal/anijs-helper-scrollreveal.js"></script>
<script>
    if ($(window).width() > 625) {
        document.write('<script src="js/imagesloaded.js"><\/script>')
        document.write('<script src="js/skrollr.js"><\/script>')
        document.write('<script src="js/_main.js"><\/script>')
        $("#menu_block").html("");
    } else {
        $("#slide-1").html("");
        $("#slide-2").html("");
    }
    $(window).scroll(function() {
        if ($(window).scrollTop() > 20) {
            $("#head").addClass("fixedheader");
            $("#logoimg").addClass("fixedlogo");
            $("#menuul").addClass("fixedmenuul");
            $("#menu ul li a").addClass("fixedmenuul_a");
            $("#fixedhead_duplicate").removeClass("hide");
        }
        if ($(window).scrollTop() < 20) {
            $("#head").removeClass("fixedheader");
            $("#logoimg").removeClass("fixedlogo");
            $("#menuul").removeClass("fixedmenuul");
            $("#menu ul li a").removeClass("fixedmenuul_a");
            $("#fixedhead_duplicate").addClass("hide");
        }

    });

    function showmenu() {
        $("#outer_container").toggleClass("block_active");
        $("#menu_block").toggleClass("iconslistactive");
    }

</script>
<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-70331300-1', 'auto');
ga('send', 'pageview');
</script>
<!-- End Google Analytics -->

</html>
